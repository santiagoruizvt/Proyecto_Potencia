El archivo FERIADOS.txt por default incluye lo siguiente:

- Setea los feriados del 2023

- Setea los eventos de la semana en los horarios que se cursa en la facultad 

	Lunes a viernes:	turno mañana, tarde y noche
	Sabado: 		turno mañana y tarde
	Domingo: 		apagado
